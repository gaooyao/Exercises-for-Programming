#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* 以下为文件读取插件 */
/* 以下为文件读取插件 */
/* 以下为文件读取插件 */

typedef struct FileHandler
{                             //文件handler
    FILE *file;               //原始文件操作handler
    char file_name[256];      //被打开的文件名
    int open_status;          //文件打开状态，0未打开，1读模式，2写模式
    int point;                //当前在buffer中的操作位置指针
    unsigned int buffer_size; //缓冲区大小
    char *buffer;             //缓冲区
} FileHandler;

int FILE_BUFFER_SIZE = 1024; //文件缓冲区大小，单位字节

/*
* 函数名称：open_file
* 函数功能：根据给定属性创建新的FileHandler对象
* 参数：    file_name：要打开的文件名
*          open_type:文件打开类型，如"r","w"
* 返回值：FileHandler指针
*/
FileHandler *open_file(char *file_name, char *open_type)
{
    if (strcmp(open_type, "rb") && strcmp(open_type, "wb"))
    {
        return 0; //如果文件打开模式错误，则终止打开文件
    }
    /* 创建FileHandler */
    FileHandler *file_handler = (FileHandler *)malloc(sizeof(FileHandler));
    if (!file_handler)
    {
        printf("open %s fail!", file_name);
        return NULL;
    }
    /* 打开文件 */
    FILE *_file = (FILE *)malloc(sizeof(FILE));
    _file = fopen((const char *)file_name, open_type);
    if (!_file)
    {
        printf("open %s fail!", file_name);
        return NULL;
    }
    file_handler->file = _file;
    /* 创建文件缓冲buffer */
    file_handler->buffer_size = FILE_BUFFER_SIZE;
    file_handler->buffer = (char *)malloc(file_handler->buffer_size);
    if (!file_handler->buffer)
    {
        fclose(file_handler->file);
        return 0; //分配内存失败
    }
    /* FileHandler属性初始化 */
    strcpy(file_handler->file_name, file_name);
    file_handler->open_status = (!strcmp(open_type, "rb") ? 1 : 2); //三元表达式
    file_handler->point = -1;
    return file_handler;
}

/*
* 函数名称：read_line
* 函数功能：从文件中读取一行文本
* 参数：	file_handler：被读取的FileHandler对象
*		    str：存放被读取文本的地址
* 返回值：int，1为读取成功，0为读取失败
*/
int read_line(FileHandler *file_handler, char **str)
{
    if (file_handler->open_status != 1)
    {
        return 0; //打开模式为写入时不允许读取
    }
    int old_point = file_handler->point; //记录当前指针位置
    if (file_handler->point != -1 && *(file_handler->buffer + file_handler->point) == -1)
    {
        return 0; //如果已读到文件末尾则直接返回
    }
    do
    {
        if (*(file_handler->buffer + file_handler->point) == -1) //遍历时如果遇到文件结束符则返回最后一行的开始指针
        {
            (*str) = (file_handler->buffer + old_point + 1);
            return 1;
        }
        //根据当前指针判断是否需要读入新数据
        int is_read_new_data = 0;
        //如果buffer为空，则读入新buffer
        if (file_handler->point == -1)
        {
            int read_num;
            read_num = fread(file_handler->buffer, 1, file_handler->buffer_size, file_handler->file);
            if (!read_num)
            {
                return 0;
            }
            else
            {
                if (read_num < file_handler->buffer_size)
                {
                    *(file_handler->buffer + read_num) = -1; //如果读入的数据是整个文件的最后一块，则读入的数据最后面加一个文件结束符
                }
                is_read_new_data = 1;
            }
        }
        //如果buffer内不足一行，则读入新数据
        if (file_handler->point + 1 >= file_handler->buffer_size)
        {
            //copy buffer尾部数据至头部
            int copy_num = 0;
            old_point++;
            while (old_point < file_handler->buffer_size)
            {
                *(file_handler->buffer + copy_num) = *(file_handler->buffer + old_point);
                old_point++;
                copy_num++;
            }
            //读入新数据
            int read_num;
            read_num = fread((char *)(file_handler->buffer + copy_num), 1, file_handler->buffer_size - copy_num, file_handler->file);
            if (!read_num)
            {
                return 0;
            }
            else
            {
                if (copy_num + read_num < file_handler->buffer_size)
                {
                    *(file_handler->buffer + copy_num + read_num) = -1; //如果读入的数据是整个文件的最后一块，则读入的数据最后面加一个文件结束符
                }
                is_read_new_data = 1;
            }
        }
        //若读入新数据则重置buffer指针
        if (is_read_new_data)
        {
            file_handler->point = 0;
            //判断读入的新数据是否可用
            while (*(file_handler->buffer + file_handler->point) != 10 && *(file_handler->buffer + file_handler->point) != 0 && *(file_handler->buffer + file_handler->point) != -1)
            {
                file_handler->point++;
                if (file_handler->point > file_handler->buffer_size)
                {
                    //读取到的整个buffer内容少于一行，则超过最大处理大小//-1结束//10换行符
                    system("stop");
                    return 0;
                }
            }
            //数据读取成功，str指针指向字符串开头并返回
            *(file_handler->buffer + file_handler->point) = 0; //断行
            (*str) = &(file_handler->buffer[0]);
            return 1;
        }
        file_handler->point++;
    } while (*(file_handler->buffer + file_handler->point) != '\n'); //point指针循环后移，直到遇到换行符则停止
    //没有读入新数据，但已找到被读文本的开头和结尾
    *(file_handler->buffer + file_handler->point) = 0; //断行
    (*str) = (file_handler->buffer + old_point + 1);
    return 1;
}

/*
* 函数名称：write_line
* 函数功能：写入文件
* 参数：	file_handler：被写入的FileHandler对象
            str：被写入的字符串
* 返回值：int,是否写入成功
*/
int write_line(FileHandler *file_handler, char *str)
{
    if (file_handler->open_status != 2)
    {
        return 0; //如果文件为读模式则不允许写入
    }
    while (*str != 0 && *str != -1) //每次在buffer中写入一字节，直到遇到结束符
    {
        file_handler->point++;
        if (file_handler->point >= file_handler->buffer_size) //如果buffer已满，则把当前buffer缓存数据写入文件，然后从buffer开始位置继续写入
        {
            fwrite(file_handler->buffer, file_handler->buffer_size, 1, file_handler->file);
            file_handler->point = 0;
        }
        *(file_handler->buffer + file_handler->point) = *str;
        str++;
    }
    file_handler->point++;
    if (file_handler->point >= file_handler->buffer_size) //buffer中额外写入一个换行符，如果buffer已满，则把当前buffer缓存数据写入文件，然后从buffer开始位置继续写入
    {
        fwrite(file_handler->buffer, file_handler->buffer_size, 1, file_handler->file);
        file_handler->point = 0;
    }
    *(file_handler->buffer + file_handler->point) = 10;
    return 0;
}

/*
* 函数名称：reset_file
* 函数功能：重置FileHandler对象，返回到文件开头
* 参数：	file_handler：被重置的FileHandler对象
* 返回值：int,是否重置成功
*/
int reset_file(FileHandler *file_handler)
{
    if (file_handler->open_status != 1)
        return 0; //打开模式为写入时不允许回到文件开头
    file_handler->point = -1;
    rewind(file_handler->file);
    return 1;
}

/*r
* 函数名称：close_file
* 函数功能：关闭文件，释放FileHandler对象
* 参数：	file_handler：被关闭的FileHandler对象
* 返回值：int,是否关闭成功
*/
int close_file(FileHandler *file_handler)
{
    //若文件为写入方式打开，则把缓冲区内容写入文件
    if (file_handler->open_status == 2 && file_handler->point != -1)
    {
        fwrite(file_handler->buffer, file_handler->point, 1, file_handler->file);
    }
    //关闭文件并释放空间
    fclose(file_handler->file);
    free(file_handler->buffer);
    file_handler->open_status = 0;
    free(file_handler);
    return 1;
}

/* 以下为树部分 */
/* 以下为树部分 */
/* 以下为树部分 */
/* 以下为树部分 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define M 2 //M叉树的叉数

typedef struct m_tree_node //M叉树的节点
{
    char is_end;                       //是否有字符串以此节点结束
    struct m_tree_node *child[1 << M]; //M个子节点
} MTNode;

void mtrie_init_tree();              //初始化树
int mtrie_insert_recoder(char *str); //插入节点
int mtrie_query_recoder(char *str);  //查询节点
void mtrie_destroy_tree();           //释放树

static MTNode *root; //M叉树的树根

/*
* 函数名称：create_new_node
* 函数功能：创建新的节点
*/
MTNode *create_new_node()
{
    int i;
    MTNode *node = (MTNode *)malloc(sizeof(MTNode));
    node->is_end = 0;
    for (i = 0; i < (1 << M); i++)
    {
        node->child[i] = NULL;
    }
    return node;
}

/*
* 函数名称：calc
* 函数功能：根据所给字符串，位置k以及叉数M，计算字符串K位置应在第几分叉
*/
unsigned int calc(unsigned int k, char *str)
{
    int n = k * M / 8;
    int l = k * M % 8;
    return (unsigned char)(((unsigned char)(str[n])) << l) >> (((8 / M) - 1) * M);
}

/*
* 函数名称：free_node
* 函数功能：释放一个节点
*/
void free_node(MTNode *node)
{
    int i = (1 << M) - 1;
    for (; i >= 0; i--)
    {
        if (node->child[i])
        {
            free_node(node->child[i]);
        }
    }
    free(node);
}

/*
* 函数名称：mtrie_init_tree
* 函数功能：初始化树
*/
void mtrie_init_tree()
{
    root = create_new_node();
}

/*
* 函数名称：mtrie_insert_recoder
* 函数功能：树中插入一个节点
*/
int mtrie_insert_recoder(char *str)
{
    int num = strlen(str) * 8 / M; //计算该字符串在树中的深度
    int i;
    MTNode *point = root;
    //从根节点开始，依次判断该字符串在树中路径上的节点是否存在，存在则继续向下遍历，不存在则创建新的节点
    for (i = 0; i < num; i++)
    {
        unsigned int p = calc(i, str);
        if (!point->child[p]) //判断对应子节点是否存在
        {
            point->child[p] = create_new_node(); //不存在则创建新节点
        }
        point = point->child[p];
    }
    point->is_end = 1; //最后一个节点的is_end置true表明走过此路径的字符串出现过
    return 1;
}

/*
* 函数名称：mtrie_query_recoder
* 函数功能：查询字符串是否出现过
*/
int mtrie_query_recoder(char *str)
{
    int num = strlen(str) * 8 / M;
    int i;
    MTNode *point = root;
    //从根节点开始，依次判断该字符串在树中路径上的节点是否存在，存在则继续向下遍历，不存在则返回false
    for (i = 0; i < num; i++)
    {
        unsigned int p = calc(i, str);
        if (!point->child[p])
        {
            return 0;
        }
        point = point->child[p];
    }
    return num ? point->is_end ? 1 : 0 : 0;
}

/*
* 函数名称：mtrie_destroy_tree
* 函数功能：释放树
*/
void mtrie_destroy_tree()
{
    free_node(root);
}

/* 以下为main函数 */
/* 以下为main函数 */
/* 以下为main函数 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

clock_t start, end;
int main()
{
    int i;
    char *str = NULL;
    //打开文件
    FileHandler *file_dict;
    FileHandler *file_string;
    FileHandler *file_result;
    //输出文件列表
    char *result_file_list[4] = {"bupt_37_1.txt", "bupt_37_2.txt", "bupt_37_3.txt", "bupt_37_4.txt"};
    file_dict = open_file("dict.txt", "rb");
    file_string = open_file("string.txt", "rb");
    //4个函数指针根据搜索方法指向相应的tree函数
    typedef void (*init_tree_function)();
    typedef int (*insert_recoder_function)(char *str);
    typedef int (*query_recoder_function)(char *str);
    typedef void (*destroy_tree_function)();
    init_tree_function init_tree;
    insert_recoder_function insert_recoder;
    query_recoder_function query_recoder;
    destroy_tree_function destroy_tree;

    init_tree = mtrie_init_tree;
    insert_recoder = mtrie_insert_recoder;
    query_recoder = mtrie_query_recoder;
    destroy_tree = mtrie_destroy_tree;
    file_result = open_file(result_file_list[2], "wb");

    start = clock();
    int kk = 0;
    //初始化树
    init_tree();
    //读入数据并建树
    while (read_line(file_dict, &str))
    {
        insert_recoder(str);
    }
    //读入数据并查询
    while (read_line(file_string, &str))
    {
        if (query_recoder(str))
        {
            kk++;
            //若查询成功则把字符串写入输出文件
            write_line(file_result, str);
        }
    }
    end = clock();
    printf("runtime: %f s, string_match:%d\n", (float)(end - start) / CLOCKS_PER_SEC, kk);
    //搜索完成，释放树

    //destroy_tree();//执行此函数会释放树，导致统计内存占用不准确

    //关闭输出文件，重置dict,string文件以备下次搜索使用
    close_file(file_result);

    //全部搜索结束，关闭文件
    close_file(file_dict);
    close_file(file_string);
    sleep(3);
    return 0;
}
