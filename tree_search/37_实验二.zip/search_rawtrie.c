#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* 以下为文件读取插件 */
/* 以下为文件读取插件 */
/* 以下为文件读取插件 */

typedef struct FileHandler
{                             //文件handler
    FILE *file;               //原始文件操作handler
    char file_name[256];      //被打开的文件名
    int open_status;          //文件打开状态，0未打开，1读模式，2写模式
    int point;                //当前在buffer中的操作位置指针
    unsigned int buffer_size; //缓冲区大小
    char *buffer;             //缓冲区
} FileHandler;

int FILE_BUFFER_SIZE = 1024; //文件缓冲区大小，单位字节

/*
* 函数名称：open_file
* 函数功能：根据给定属性创建新的FileHandler对象
* 参数：    file_name：要打开的文件名
*          open_type:文件打开类型，如"r","w"
* 返回值：FileHandler指针
*/
FileHandler *open_file(char *file_name, char *open_type)
{
    if (strcmp(open_type, "rb") && strcmp(open_type, "wb"))
    {
        return 0; //如果文件打开模式错误，则终止打开文件
    }
    /* 创建FileHandler */
    FileHandler *file_handler = (FileHandler *)malloc(sizeof(FileHandler));
    if (!file_handler)
    {
        printf("open %s fail!", file_name);
        return NULL;
    }
    /* 打开文件 */
    FILE *_file = (FILE *)malloc(sizeof(FILE));
    _file = fopen((const char *)file_name, open_type);
    if (!_file)
    {
        printf("open %s fail!", file_name);
        return NULL;
    }
    file_handler->file = _file;
    /* 创建文件缓冲buffer */
    file_handler->buffer_size = FILE_BUFFER_SIZE;
    file_handler->buffer = (char *)malloc(file_handler->buffer_size);
    if (!file_handler->buffer)
    {
        fclose(file_handler->file);
        return 0; //分配内存失败
    }
    /* FileHandler属性初始化 */
    strcpy(file_handler->file_name, file_name);
    file_handler->open_status = (!strcmp(open_type, "rb") ? 1 : 2); //三元表达式
    file_handler->point = -1;
    return file_handler;
}

/*
* 函数名称：read_line
* 函数功能：从文件中读取一行文本
* 参数：	file_handler：被读取的FileHandler对象
*		    str：存放被读取文本的地址
* 返回值：int，1为读取成功，0为读取失败
*/
int read_line(FileHandler *file_handler, char **str)
{
    if (file_handler->open_status != 1)
    {
        return 0; //打开模式为写入时不允许读取
    }
    int old_point = file_handler->point; //记录当前指针位置
    if (file_handler->point != -1 && *(file_handler->buffer + file_handler->point) == -1)
    {
        return 0; //如果已读到文件末尾则直接返回
    }
    do
    {
        if (*(file_handler->buffer + file_handler->point) == -1) //遍历时如果遇到文件结束符则返回最后一行的开始指针
        {
            (*str) = (file_handler->buffer + old_point + 1);
            return 1;
        }
        //根据当前指针判断是否需要读入新数据
        int is_read_new_data = 0;
        //如果buffer为空，则读入新buffer
        if (file_handler->point == -1)
        {
            int read_num;
            read_num = fread(file_handler->buffer, 1, file_handler->buffer_size, file_handler->file);
            if (!read_num)
            {
                return 0;
            }
            else
            {
                if (read_num < file_handler->buffer_size)
                {
                    *(file_handler->buffer + read_num) = -1; //如果读入的数据是整个文件的最后一块，则读入的数据最后面加一个文件结束符
                }
                is_read_new_data = 1;
            }
        }
        //如果buffer内不足一行，则读入新数据
        if (file_handler->point + 1 >= file_handler->buffer_size)
        {
            //copy buffer尾部数据至头部
            int copy_num = 0;
            old_point++;
            while (old_point < file_handler->buffer_size)
            {
                *(file_handler->buffer + copy_num) = *(file_handler->buffer + old_point);
                old_point++;
                copy_num++;
            }
            //读入新数据
            int read_num;
            read_num = fread((char *)(file_handler->buffer + copy_num), 1, file_handler->buffer_size - copy_num, file_handler->file);
            if (!read_num)
            {
                return 0;
            }
            else
            {
                if (copy_num + read_num < file_handler->buffer_size)
                {
                    *(file_handler->buffer + copy_num + read_num) = -1; //如果读入的数据是整个文件的最后一块，则读入的数据最后面加一个文件结束符
                }
                is_read_new_data = 1;
            }
        }
        //若读入新数据则重置buffer指针
        if (is_read_new_data)
        {
            file_handler->point = 0;
            //判断读入的新数据是否可用
            while (*(file_handler->buffer + file_handler->point) != 10 && *(file_handler->buffer + file_handler->point) != 0 && *(file_handler->buffer + file_handler->point) != -1)
            {
                file_handler->point++;
                if (file_handler->point > file_handler->buffer_size)
                {
                    //读取到的整个buffer内容少于一行，则超过最大处理大小//-1结束//10换行符
                    system("stop");
                    return 0;
                }
            }
            //数据读取成功，str指针指向字符串开头并返回
            *(file_handler->buffer + file_handler->point) = 0; //断行
            (*str) = &(file_handler->buffer[0]);
            return 1;
        }
        file_handler->point++;
    } while (*(file_handler->buffer + file_handler->point) != '\n'); //point指针循环后移，直到遇到换行符则停止
    //没有读入新数据，但已找到被读文本的开头和结尾
    *(file_handler->buffer + file_handler->point) = 0; //断行
    (*str) = (file_handler->buffer + old_point + 1);
    return 1;
}

/*
* 函数名称：write_line
* 函数功能：写入文件
* 参数：	file_handler：被写入的FileHandler对象
            str：被写入的字符串
* 返回值：int,是否写入成功
*/
int write_line(FileHandler *file_handler, char *str)
{
    if (file_handler->open_status != 2)
    {
        return 0; //如果文件为读模式则不允许写入
    }
    while (*str != 0 && *str != -1) //每次在buffer中写入一字节，直到遇到结束符
    {
        file_handler->point++;
        if (file_handler->point >= file_handler->buffer_size) //如果buffer已满，则把当前buffer缓存数据写入文件，然后从buffer开始位置继续写入
        {
            fwrite(file_handler->buffer, file_handler->buffer_size, 1, file_handler->file);
            file_handler->point = 0;
        }
        *(file_handler->buffer + file_handler->point) = *str;
        str++;
    }
    file_handler->point++;
    if (file_handler->point >= file_handler->buffer_size) //buffer中额外写入一个换行符，如果buffer已满，则把当前buffer缓存数据写入文件，然后从buffer开始位置继续写入
    {
        fwrite(file_handler->buffer, file_handler->buffer_size, 1, file_handler->file);
        file_handler->point = 0;
    }
    *(file_handler->buffer + file_handler->point) = 10;
    return 0;
}

/*
* 函数名称：reset_file
* 函数功能：重置FileHandler对象，返回到文件开头
* 参数：	file_handler：被重置的FileHandler对象
* 返回值：int,是否重置成功
*/
int reset_file(FileHandler *file_handler)
{
    if (file_handler->open_status != 1)
        return 0; //打开模式为写入时不允许回到文件开头
    file_handler->point = -1;
    rewind(file_handler->file);
    return 1;
}

/*r
* 函数名称：close_file
* 函数功能：关闭文件，释放FileHandler对象
* 参数：	file_handler：被关闭的FileHandler对象
* 返回值：int,是否关闭成功
*/
int close_file(FileHandler *file_handler)
{
    //若文件为写入方式打开，则把缓冲区内容写入文件
    if (file_handler->open_status == 2 && file_handler->point != -1)
    {
        fwrite(file_handler->buffer, file_handler->point, 1, file_handler->file);
    }
    //关闭文件并释放空间
    fclose(file_handler->file);
    free(file_handler->buffer);
    file_handler->open_status = 0;
    free(file_handler);
    return 1;
}

/* 以下为树部分 */
/* 以下为树部分 */
/* 以下为树部分 */
/* 以下为树部分 */

typedef struct TrieNode
{                                //rawrite树节点
    struct TrieNode *child[256]; //子节点数组
    unsigned char is_end;        //此节点是否为某字符串结尾
} TrieNode;

void rawtrie_init_tree();              //初始化树
int rawtrie_insert_recoder(char *str); //插入记录
int rawtrie_query_recoder(char *str);  //查询记录
void rawtrie_destroy_tree();           //释放树

TrieNode *root; //根节点

/*
* 函数名称：free_trie_node
* 函数功能：释放一个节点
*/
void free_trie_node(TrieNode *node)
{
    int i = 255;
    for (; i >= 0; i--)
    {
        if (node->child[i])
        {
            free_trie_node(node->child[i]);
        }
    }
    free(node);
}

/*
* 函数名称：rawtrie_init_tree
* 函数功能：初始化树
*/
void rawtrie_init_tree()
{
    root = (TrieNode *)malloc(sizeof(TrieNode));

    root->is_end = 0;
    int i;
    for (i = 0; i < 256; i++)
    {
        root->child[i] = NULL;
    }
}

/*
* 函数名称：rawtrie_new_node
* 函数功能：创建新的节点
*/
TrieNode *rawtrie_new_node()
{
    TrieNode *obj = (TrieNode *)malloc(sizeof(TrieNode));
    obj->is_end = 0;
    int i;
    for (i = 0; i < 256; i++)
    {
        obj->child[i] = NULL;
    }
    return obj;
}

/*
* 函数名称：rawtrie_insert_recoder
* 函数功能：插入一条记录
*/
int rawtrie_insert_recoder(char *str)
{
    char *p = str;
    TrieNode *node = root;
    while (*p != '\0')
    {
        if (node->child[(unsigned char)*p] == NULL)
        {
            /* 对应的节点不存在，则创建一个节点 */
            node->child[(unsigned char)(*p)] = rawtrie_new_node();
        }
        node = node->child[(unsigned char)*p]; /* 指向子节点 */
        p++;
    }
    node->is_end = 1;
    return 1;
}

/*
* 函数名称：rawtrie_query_recoder
* 函数功能：查询记录是否存在
*/
int rawtrie_query_recoder(char *str)
{
    TrieNode *node = root; //指针指向root
    char *p = str;

    while (*p && node != NULL)
    {
        node = node->child[(unsigned char)*p]; /* 循环在树中查找所有节点 */
        p++;
    }

    if (node == NULL)
    {             //str未结束，而node已经不存在，则返回未找到
        return 0; /* 未找到 */
    }
    else
    {
        return (node->is_end > 0 ? (1) : (0)); //判断此节点是否为结束节点，若是则说明此纪录出现过，返回true
    }
}

/*
* 函数名称：rawtrie_destroy_tree
* 函数功能：释放树
*/
void rawtrie_destroy_tree()
{
    if (root != NULL)
    {
        free_trie_node(root);
    }
}

/* 以下为main函数 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

clock_t start, end;
int main()
{
    int i;
    char *str = NULL;
    //打开文件
    FileHandler *file_dict;
    FileHandler *file_string;
    FileHandler *file_result;
    //输出文件列表
    char *result_file_list[4] = {"bupt_37_1.txt", "bupt_37_2.txt", "bupt_37_3.txt", "bupt_37_4.txt"};
    file_dict = open_file("dict.txt", "rb");
    file_string = open_file("string.txt", "rb");
    //4个函数指针根据搜索方法指向相应的tree函数
    typedef void (*init_tree_function)();
    typedef int (*insert_recoder_function)(char *str);
    typedef int (*query_recoder_function)(char *str);
    typedef void (*destroy_tree_function)();
    init_tree_function init_tree;
    insert_recoder_function insert_recoder;
    query_recoder_function query_recoder;
    destroy_tree_function destroy_tree;

    init_tree = rawtrie_init_tree;
    insert_recoder = rawtrie_insert_recoder;
    query_recoder = rawtrie_query_recoder;
    destroy_tree = rawtrie_destroy_tree;
    file_result = open_file(result_file_list[1], "wb");

    start = clock();
    int kk = 0;
    //初始化树
    init_tree();
    //读入数据并建树
    while (read_line(file_dict, &str))
    {
        insert_recoder(str);
    }
    //读入数据并查询
    while (read_line(file_string, &str))
    {
        if (query_recoder(str))
        {
            kk++;
            //若查询成功则把字符串写入输出文件
            write_line(file_result, str);
        }
    }
    end = clock();
    printf("runtime: %f s, string_match:%d\n", (float)(end - start) / CLOCKS_PER_SEC, kk);
    //搜索完成，释放树

    //destroy_tree();//执行此函数会释放树，导致统计内存占用不准确

    //关闭输出文件，重置dict,string文件以备下次搜索使用
    close_file(file_result);

    //全部搜索结束，关闭文件
    close_file(file_dict);
    close_file(file_string);
    sleep(3);
    return 0;
}
