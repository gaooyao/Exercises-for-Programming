
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* 以下为hash函数部分 */
/* 以下为hash函数部分 */
/* 以下为hash函数部分 */
/* 以下为hash函数部分 */

unsigned long rotl64_self(uint64_t x, int8_t r)
{
    return (x << r) | (x >> (64 - r));
}

// Microsoft Visual Studio

#if defined(_MSC_VER)

#define FORCE_INLINE __forceinline

#define ROTL32(x, y) _rotl(x, y)
#define ROTL64(x, y) _rotl64_self(x, y)

#define BIG_CONSTANT(x) (x)

// Other compilers

#else // defined(_MSC_VER)

#define FORCE_INLINE inline __attribute__((always_inline))

inline uint32_t rotl32(uint32_t x, int8_t r)
{
    return (x << r) | (x >> (32 - r));
}

inline uint64_t rotl64(uint64_t x, int8_t r)
{
    return (x << r) | (x >> (64 - r));
}

#define ROTL32(x, y) rotl32(x, y)
#define ROTL64(x, y) _rotl64_self(x, y)

#define BIG_CONSTANT(x) (x##LLU)

#endif // !defined(_MSC_VER)

//-----------------------------------------------------------------------------
// Block read - if your platform needs to do endian-swapping or can only
// handle aligned reads, do the conversion here

FORCE_INLINE uint32_t getblock32(const uint32_t *p, int i)
{
    return p[i];
}

FORCE_INLINE uint64_t getblock64(const uint64_t *p, int i)
{
    return p[i];
}

//-----------------------------------------------------------------------------
// Finalization mix - force all bits of a hash block to avalanche

FORCE_INLINE uint32_t fmix32(uint32_t h)
{
    h ^= h >> 16;
    h *= 0x85ebca6b;
    h ^= h >> 13;
    h *= 0xc2b2ae35;
    h ^= h >> 16;

    return h;
}

//----------

FORCE_INLINE uint64_t fmix64(uint64_t k)
{
    k ^= k >> 33;
    k *= BIG_CONSTANT(0xff51afd7ed558ccd);
    k ^= k >> 33;
    k *= BIG_CONSTANT(0xc4ceb9fe1a85ec53);
    k ^= k >> 33;

    return k;
}

void MurmurHash3_x64_128(const void *key, const int len, const uint32_t seed, void *out)
{
    const uint8_t *data = (const uint8_t *)key;
    const int nblocks = len / 16;
    uint64_t h1 = seed;
    uint64_t h2 = seed;
    const uint64_t c1 = BIG_CONSTANT(0x87c37b91114253d5);
    const uint64_t c2 = BIG_CONSTANT(0x4cf5ad432745937f);
    const uint64_t *blocks = (const uint64_t *)(data);
    for (int i = 0; i < nblocks; i++)
    {
        uint64_t k1 = getblock64(blocks, i * 2 + 0);
        uint64_t k2 = getblock64(blocks, i * 2 + 1);
        k1 *= c1;
        k1 = rotl64_self(k1, 31);
        k1 *= c2;
        h1 ^= k1;
        h1 = rotl64_self(h1, 27);
        h1 += h2;
        h1 = h1 * 5 + 0x52dce729;
        k2 *= c2;
        k2 = rotl64_self(k2, 33);
        k2 *= c1;
        h2 ^= k2;
        h2 = rotl64_self(h2, 31);
        h2 += h1;
        h2 = h2 * 5 + 0x38495ab5;
    }
    const uint8_t *tail = (const uint8_t *)(data + nblocks * 16);
    uint64_t k1 = 0;
    uint64_t k2 = 0;
    switch (len & 15)
    {
    case 15:
        k2 ^= ((uint64_t)tail[14]) << 48;
    case 14:
        k2 ^= ((uint64_t)tail[13]) << 40;
    case 13:
        k2 ^= ((uint64_t)tail[12]) << 32;
    case 12:
        k2 ^= ((uint64_t)tail[11]) << 24;
    case 11:
        k2 ^= ((uint64_t)tail[10]) << 16;
    case 10:
        k2 ^= ((uint64_t)tail[9]) << 8;
    case 9:
        k2 ^= ((uint64_t)tail[8]) << 0;
        k2 *= c2;
        k2 = rotl64_self(k2, 33);
        k2 *= c1;
        h2 ^= k2;
    case 8:
        k1 ^= ((uint64_t)tail[7]) << 56;
    case 7:
        k1 ^= ((uint64_t)tail[6]) << 48;
    case 6:
        k1 ^= ((uint64_t)tail[5]) << 40;
    case 5:
        k1 ^= ((uint64_t)tail[4]) << 32;
    case 4:
        k1 ^= ((uint64_t)tail[3]) << 24;
    case 3:
        k1 ^= ((uint64_t)tail[2]) << 16;
    case 2:
        k1 ^= ((uint64_t)tail[1]) << 8;
    case 1:
        k1 ^= ((uint64_t)tail[0]) << 0;
        k1 *= c1;
        k1 = rotl64_self(k1, 31);
        k1 *= c2;
        h1 ^= k1;
    };
    h1 ^= len;
    h2 ^= len;
    h1 += h2;
    h2 += h1;
    h1 = fmix64(h1);
    h2 = fmix64(h2);
    h1 += h2;
    h2 += h1;
    ((uint64_t *)out)[0] = h1;
    ((uint64_t *)out)[1] = h2;
}

/* 以下为文件读取插件 */
/* 以下为文件读取插件 */
/* 以下为文件读取插件 */

typedef struct FileHandler
{                             //文件handler
    FILE *file;               //原始文件操作handler
    char file_name[256];      //被打开的文件名
    int open_status;          //文件打开状态，0未打开，1读模式，2写模式
    int point;                //当前在buffer中的操作位置指针
    unsigned int buffer_size; //缓冲区大小
    char *buffer;             //缓冲区
} FileHandler;

int FILE_BUFFER_SIZE = 1024; //文件缓冲区大小，单位字节

/*
* 函数名称：open_file
* 函数功能：根据给定属性创建新的FileHandler对象
* 参数：    file_name：要打开的文件名
*          open_type:文件打开类型，如"r","w"
* 返回值：FileHandler指针
*/
FileHandler *open_file(char *file_name, char *open_type)
{
    if (strcmp(open_type, "rb") && strcmp(open_type, "wb"))
    {
        return 0; //如果文件打开模式错误，则终止打开文件
    }
    /* 创建FileHandler */
    FileHandler *file_handler = (FileHandler *)malloc(sizeof(FileHandler));
    if (!file_handler)
    {
        printf("open %s fail!", file_name);
        return NULL;
    }
    /* 打开文件 */
    FILE *_file = (FILE *)malloc(sizeof(FILE));
    _file = fopen((const char *)file_name, open_type);
    if (!_file)
    {
        printf("open %s fail!", file_name);
        return NULL;
    }
    file_handler->file = _file;
    /* 创建文件缓冲buffer */
    file_handler->buffer_size = FILE_BUFFER_SIZE;
    file_handler->buffer = (char *)malloc(file_handler->buffer_size);
    if (!file_handler->buffer)
    {
        fclose(file_handler->file);
        return 0; //分配内存失败
    }
    /* FileHandler属性初始化 */
    strcpy(file_handler->file_name, file_name);
    file_handler->open_status = (!strcmp(open_type, "rb") ? 1 : 2); //三元表达式
    file_handler->point = -1;
    return file_handler;
}

/*
* 函数名称：read_line
* 函数功能：从文件中读取一行文本
* 参数：	file_handler：被读取的FileHandler对象
*		    str：存放被读取文本的地址
* 返回值：int，1为读取成功，0为读取失败
*/
int read_line(FileHandler *file_handler, char **str)
{
    if (file_handler->open_status != 1)
    {
        return 0; //打开模式为写入时不允许读取
    }
    int old_point = file_handler->point; //记录当前指针位置
    if (file_handler->point != -1 && *(file_handler->buffer + file_handler->point) == -1)
    {
        return 0; //如果已读到文件末尾则直接返回
    }
    do
    {
        if (*(file_handler->buffer + file_handler->point) == -1) //遍历时如果遇到文件结束符则返回最后一行的开始指针
        {
            (*str) = (file_handler->buffer + old_point + 1);
            return 1;
        }
        //根据当前指针判断是否需要读入新数据
        int is_read_new_data = 0;
        //如果buffer为空，则读入新buffer
        if (file_handler->point == -1)
        {
            int read_num;
            read_num = fread(file_handler->buffer, 1, file_handler->buffer_size, file_handler->file);
            if (!read_num)
            {
                return 0;
            }
            else
            {
                if (read_num < file_handler->buffer_size)
                {
                    *(file_handler->buffer + read_num) = -1; //如果读入的数据是整个文件的最后一块，则读入的数据最后面加一个文件结束符
                }
                is_read_new_data = 1;
            }
        }
        //如果buffer内不足一行，则读入新数据
        if (file_handler->point + 1 >= file_handler->buffer_size)
        {
            //copy buffer尾部数据至头部
            int copy_num = 0;
            old_point++;
            while (old_point < file_handler->buffer_size)
            {
                *(file_handler->buffer + copy_num) = *(file_handler->buffer + old_point);
                old_point++;
                copy_num++;
            }
            //读入新数据
            int read_num;
            read_num = fread((char *)(file_handler->buffer + copy_num), 1, file_handler->buffer_size - copy_num, file_handler->file);
            if (!read_num)
            {
                return 0;
            }
            else
            {
                if (copy_num + read_num < file_handler->buffer_size)
                {
                    *(file_handler->buffer + copy_num + read_num) = -1; //如果读入的数据是整个文件的最后一块，则读入的数据最后面加一个文件结束符
                }
                is_read_new_data = 1;
            }
        }
        //若读入新数据则重置buffer指针
        if (is_read_new_data)
        {
            file_handler->point = 0;
            //判断读入的新数据是否可用
            while (*(file_handler->buffer + file_handler->point) != 10 && *(file_handler->buffer + file_handler->point) != 0 && *(file_handler->buffer + file_handler->point) != -1)
            {
                file_handler->point++;
                if (file_handler->point > file_handler->buffer_size)
                {
                    //读取到的整个buffer内容少于一行，则超过最大处理大小//-1结束//10换行符
                    system("stop");
                    return 0;
                }
            }
            //数据读取成功，str指针指向字符串开头并返回
            *(file_handler->buffer + file_handler->point) = 0; //断行
            (*str) = &(file_handler->buffer[0]);
            return 1;
        }
        file_handler->point++;
    } while (*(file_handler->buffer + file_handler->point) != '\n'); //point指针循环后移，直到遇到换行符则停止
    //没有读入新数据，但已找到被读文本的开头和结尾
    *(file_handler->buffer + file_handler->point) = 0; //断行
    (*str) = (file_handler->buffer + old_point + 1);
    return 1;
}

/*
* 函数名称：write_line
* 函数功能：写入文件
* 参数：	file_handler：被写入的FileHandler对象
            str：被写入的字符串
* 返回值：int,是否写入成功
*/
int write_line(FileHandler *file_handler, char *str)
{
    if (file_handler->open_status != 2)
    {
        return 0; //如果文件为读模式则不允许写入
    }
    while (*str != 0 && *str != -1) //每次在buffer中写入一字节，直到遇到结束符
    {
        file_handler->point++;
        if (file_handler->point >= file_handler->buffer_size) //如果buffer已满，则把当前buffer缓存数据写入文件，然后从buffer开始位置继续写入
        {
            fwrite(file_handler->buffer, file_handler->buffer_size, 1, file_handler->file);
            file_handler->point = 0;
        }
        *(file_handler->buffer + file_handler->point) = *str;
        str++;
    }
    file_handler->point++;
    if (file_handler->point >= file_handler->buffer_size) //buffer中额外写入一个换行符，如果buffer已满，则把当前buffer缓存数据写入文件，然后从buffer开始位置继续写入
    {
        fwrite(file_handler->buffer, file_handler->buffer_size, 1, file_handler->file);
        file_handler->point = 0;
    }
    *(file_handler->buffer + file_handler->point) = 10;
    return 0;
}

/*
* 函数名称：reset_file
* 函数功能：重置FileHandler对象，返回到文件开头
* 参数：	file_handler：被重置的FileHandler对象
* 返回值：int,是否重置成功
*/
int reset_file(FileHandler *file_handler)
{
    if (file_handler->open_status != 1)
        return 0; //打开模式为写入时不允许回到文件开头
    file_handler->point = -1;
    rewind(file_handler->file);
    return 1;
}

/*r
* 函数名称：close_file
* 函数功能：关闭文件，释放FileHandler对象
* 参数：	file_handler：被关闭的FileHandler对象
* 返回值：int,是否关闭成功
*/
int close_file(FileHandler *file_handler)
{
    //若文件为写入方式打开，则把缓冲区内容写入文件
    if (file_handler->open_status == 2 && file_handler->point != -1)
    {
        fwrite(file_handler->buffer, file_handler->point, 1, file_handler->file);
    }
    //关闭文件并释放空间
    fclose(file_handler->file);
    free(file_handler->buffer);
    file_handler->open_status = 0;
    free(file_handler);
    return 1;
}

/* 以下为树部分 */
/* 以下为树部分 */
/* 以下为树部分 */
/* 以下为树部分 */

#define CHILD_NUM 64 //B+树的叉数

typedef struct bptree //B+树的节点
{
    uint64_t *keys;        //关键字key
    void **pointers;       //指向叶子节点内存储的字符串
    uint16_t is_leaf : 1;  //用来判断节点是否为叶子节点
    uint16_t nr_keys : 15; //节点中已存放了多少个关键字
} BPTree;

void bplus_init_tree();              //初始化树
int bplus_insert_recoder(char *str); //插入
int bplus_query_recoder(char *str);  //查询
void bplus_destroy_tree();           //释放树

/*
* 函数名称：bpt_alloc
* 函数功能：创建bplus树节点并初始化
*/
static BPTree *bpt_alloc()
{
    BPTree *bpt = malloc(sizeof(BPTree));
    if (!bpt)
    {
        return NULL;
    }
    bpt->keys = malloc(sizeof(uint64_t) * (CHILD_NUM - 1));
    if (!bpt->keys)
    {
        goto release0;
    }
    bpt->pointers = calloc(CHILD_NUM, sizeof(void *));
    if (!bpt->pointers)
    {
        goto release1;
    }
    bpt->is_leaf = 1;
    bpt->nr_keys = 0;
    bpt->pointers[0] = NULL;
    return bpt;
release1:
    free(bpt->keys);
release0:
    free(bpt);
    abort();
    return NULL;
}

/*
* 函数名称：bptree_alloc
* 函数功能：创建bplus树节点并初始化
*/
BPTree *bptree_alloc(uint64_t key, void *val)
{
    BPTree *bpt = bpt_alloc();
    bpt->nr_keys = 1;
    bpt->keys[0] = key;
    bpt->pointers[1] = val;
    return bpt;
}

/*
* 函数名称：split
* 函数功能：返回X的一半
*/
static inline int split(int x)
{
    return (x >> 1) + (x & 1);
}

/*
* 函数名称：bpt_bisect
* 函数功能：找到给定key的索引
*/
static int bpt_bisect(BPTree *bpt, uint64_t key)
{
    int low = 0;
    int high = bpt->nr_keys - 2;
    int mid = low + ((high - low) / 2);
    while (!(bpt->keys[mid] <= key && key < bpt->keys[mid + 1]))
    {
        assert(low < high);
        assert(bpt->keys[mid] != bpt->keys[mid + 1]);
        if (bpt->keys[mid] < key)
        {
            low = mid;
        }
        else if (bpt->keys[mid] > key)
        {
            high = mid - 1;
        }
        else
        {
            return mid;
        }
        mid = low == mid ? (mid + 1) : low + ((high - low) / 2);
    }
    return mid;
}

/*
* 函数名称：bpt_index
* 函数功能：查找key的指针索引
*/
static void bpt_index(BPTree *bpt, uint64_t key, int *k, int *p)
{
    assert(bpt->nr_keys > 0);
    const int last_idx = bpt->nr_keys - 1;
    if (key < bpt->keys[0])
    {
        *k = *p = 0;
    }
    else if (key >= bpt->keys[last_idx])
    {
        *k = last_idx;
        *p = last_idx + 1;
    }
    else
    {
        *k = bpt_bisect(bpt, key);
        *p = *k + 1;
    }
}

/*
* 函数名称：bptree_search
* 函数功能：查找key应在的叶子
*/
BPTree *bptree_search(BPTree *bpt, uint64_t key)
{
    int kidx, pidx;
    while (!bpt->is_leaf)
    {
        bpt_index(bpt, key, &kidx, &pidx);
        bpt = bpt->pointers[pidx];
        assert(bpt);
        assert(bpt->nr_keys >= split(CHILD_NUM) - 1);
    }
    return bpt;
}

/*
* 函数名称：bptree_exists
* 函数功能：查找key是否存在
*/
BPTree *bptree_exists(BPTree *bpt, uint64_t key)
{
    int kidx, pidx;
    bpt = bptree_search(bpt, key);
    bpt_index(bpt, key, &kidx, &pidx);
    return (bpt && bpt->keys[kidx] == key) ? bpt : NULL;
}

/*
* 函数名称：bpt_inject
* 函数功能：树中插入节点
*/
static void bpt_inject(BPTree *bpt, int pidx, uint64_t key, void *val)
{
    assert(bpt->nr_keys < CHILD_NUM - 1);
    for (int i = bpt->nr_keys; i > pidx; --i)
    {
        bpt->pointers[i + 1] = bpt->pointers[i];
    }
    bpt->pointers[pidx + 1] = val;
    for (int i = bpt->nr_keys - 1; i >= pidx; --i)
    {
        bpt->keys[i + 1] = bpt->keys[i];
    }
    bpt->keys[pidx] = key;
    ++bpt->nr_keys;
    BPTree *pred = bpt->pointers[pidx];
    if (!bpt->is_leaf && pred && pred->is_leaf)
    {
        BPTree *succ = bpt->pointers[pidx + 1];
        succ->pointers[0] = pred->pointers[0];
        pred->pointers[0] = succ;
    }
}

/*
* 函数名称：bpt_split_child
* 函数功能：根据pidx分裂一个满节点
*/
static void bpt_split_child(BPTree *parent, int pidx)
{
    BPTree *succ = bpt_alloc();
    BPTree *pred = parent->pointers[pidx];
    succ->is_leaf = pred->is_leaf;
    succ->nr_keys = split(CHILD_NUM - 1);
    pred->nr_keys = (CHILD_NUM - 1) - succ->nr_keys;
    for (int i = 0; i < succ->nr_keys; ++i)
    {
        succ->keys[i] = pred->keys[i + pred->nr_keys];
    }
    for (int i = 1; i <= succ->nr_keys; ++i)
    {
        succ->pointers[i] = pred->pointers[i + pred->nr_keys];
    }
    bpt_inject(parent, pidx, succ->keys[0], succ);
}

/*
* 函数名称：bpt_insert_nonfull
* 函数功能：value插入一个不满的叶子节点
*/
static void bpt_insert_nonfull(BPTree *bpt, uint64_t key, void *val)
{
    int kidx, pidx;
    while (!bpt->is_leaf)
    {
        bpt_index(bpt, key, &kidx, &pidx);
        if (((BPTree *)(bpt)->pointers[(pidx)])->nr_keys == CHILD_NUM - 1)
        {
            bpt_split_child(bpt, pidx);
            bpt_index(bpt, key, &kidx, &pidx);
        }
        assert(kidx < bpt->nr_keys);
        if (bpt->keys[kidx] == key)
        {
            return;
        }
        bpt = bpt->pointers[pidx];
        assert(bpt->nr_keys >= split(CHILD_NUM) - 1);
        assert(bpt->nr_keys < CHILD_NUM);
    }
    bpt_index(bpt, key, &kidx, &pidx);
    assert(kidx < bpt->nr_keys);
    if (bpt->keys[kidx] != key)
    {
        bpt_inject(bpt, pidx, key, val);
    }
}

/*
* 函数名称：bptree_insert
* 函数功能：树中插入一个value
*/
void bptree_insert(BPTree **root, uint64_t key, void *val)
{
    if ((*root)->nr_keys == CHILD_NUM - 1)
    {
        BPTree *new_root = bpt_alloc();
        new_root->is_leaf = 0;
        new_root->pointers[0] = *root;
        bpt_split_child(new_root, 0);
        *root = new_root;
        bpt_insert_nonfull(new_root, key, val);
    }
    else
    {
        bpt_insert_nonfull(*root, key, val);
    }
}

/*
* 函数名称：bpt_free
* 函数功能：释放一个节点
*/
static void bpt_free(BPTree *bpt)
{
    free(bpt->pointers);
    free(bpt->keys);
    free(bpt);
}

/*
* 函数名称：bptree_free
* 函数功能：释放整个树
*/
void bptree_free(BPTree *bpt)
{
    if (bpt->is_leaf)
    {
        bpt_free(bpt);
    }
    else
    {
        for (int i = 0; i <= bpt->nr_keys; ++i)
        {
            if (bpt->pointers[i])
            {
                bptree_free(bpt->pointers[i]);
            }
        }
        bpt_free(bpt);
    }
}

uint64_t *out[2];    //用来存放hash值
static BPTree *root; //树根

/*
* 函数名称：get_hash
* 函数功能：计算字符串的hash值
*/
uint64_t get_hash(char *str)
{
    MurmurHash3_x64_128(str, strlen(str), 31, out);
    return (uint64_t)out[0];
};

/*
* 函数名称：bplus_init_tree
* 函数功能：初始化树
*/
void bplus_init_tree()
{
    root = bptree_alloc(0, NULL);
}

/*
* 函数名称：bplus_insert_recoder
* 函数功能：树中插入字符串
*/
int bplus_insert_recoder(char *str)
{
    bptree_insert(&root, get_hash(str), str);
    return 1;
}

/*
* 函数名称：bplus_query_recoder
* 函数功能：查询字符串是否出现过
*/
int bplus_query_recoder(char *str)
{
    return bptree_exists(root, get_hash(str)) ? 1 : 0;
}
/*
* 函数名称：bplus_destroy_tree
* 函数功能：释放树
*/
void bplus_destroy_tree()
{
    bptree_free(root);
}

/* 以下为main函数 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

clock_t start, end;
int main()
{
    int i;
    char *str = NULL;
    //打开文件
    FileHandler *file_dict;
    FileHandler *file_string;
    FileHandler *file_result;
    //输出文件列表
    char *result_file_list[4] = {"bupt_37_1.txt", "bupt_37_2.txt", "bupt_37_3.txt", "bupt_37_4.txt"};
    file_dict = open_file("dict.txt", "rb");
    file_string = open_file("string.txt", "rb");
    //4个函数指针根据搜索方法指向相应的tree函数
    typedef void (*init_tree_function)();
    typedef int (*insert_recoder_function)(char *str);
    typedef int (*query_recoder_function)(char *str);
    typedef void (*destroy_tree_function)();
    init_tree_function init_tree;
    insert_recoder_function insert_recoder;
    query_recoder_function query_recoder;
    destroy_tree_function destroy_tree;

    init_tree = bplus_init_tree;
    insert_recoder = bplus_insert_recoder;
    query_recoder = bplus_query_recoder;
    destroy_tree = bplus_destroy_tree;
    file_result = open_file(result_file_list[0], "wb");

    start = clock();
    int kk = 0;
    //初始化树
    init_tree();
    //读入数据并建树
    while (read_line(file_dict, &str))
    {
        insert_recoder(str);
    }
    //读入数据并查询
    while (read_line(file_string, &str))
    {
        if (query_recoder(str))
        {
            kk++;
            //若查询成功则把字符串写入输出文件
            write_line(file_result, str);
        }
    }
    end = clock();
    printf("runtime: %f s, string_match:%d\n", (float)(end - start) / CLOCKS_PER_SEC, kk);
    //搜索完成，释放树

    //destroy_tree();//执行此函数会释放树，导致统计内存占用不准确

    //关闭输出文件，重置dict,string文件以备下次搜索使用
    close_file(file_result);

    //全部搜索结束，关闭文件
    close_file(file_dict);
    close_file(file_string);
    sleep(3);
    return 0;
}
